__author__="mbgm8je3"
__date__ ="$29-Apr-2014 13:19:42$"

from setuptools import setup,find_packages

setup (
  name = 'TeamBeck',
  version = '0.1',
  packages = find_packages(),

  # Declare your packages' dependencies here, for eg:
  install_requires=['foo>=3'],

  # Fill in these to make your Egg ready for upload to
  # PyPI
  author = 'mbgm8je3',
  author_email = '',

  summary = 'Just another Python package for the cheese shop',
  url = '',
  license = '',
  long_description= 'Long description of the package',

  # could also include long_description, download_url, classifiers, etc.

  
)